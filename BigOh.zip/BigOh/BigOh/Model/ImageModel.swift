//
//  ImageModel.swift
//  BigOh
//
//  Created by Palak Satti on 18/10/24.
//

import Foundation


//for normal/initial loading

struct ImageData: Codable {
    let id: String?
    let urls: ImageURLs?
    
}
struct ImageURLs: Codable {
    let regular: String?
    let small: String?
    let thumb: String?
}

//for keyword loading

struct ImageKeywordResponse: Codable {
    let total, totalPages: Int?
    let results: [Result]?
}
struct Result: Codable {
    let id, slug: String?
    let createdAt, updatedAt: Date?
    let promotedAt: Date?
    let width, height: Int?
    let color, blurHash: String?
    let description: String?
    let altDescription: String?
    let urls: Urls?
    let likes: Int?
}
struct Urls: Codable {
    let raw, full, regular, small: String?
    let thumb, smallS3: String?
}
