//
//  ImagesCollectionViewCell.swift
//  ImageLoder
//
//  Created by Palak Satti on 18/10/24.
//

import UIKit

class ImagesCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var imgImage: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        viewBackground.layer.cornerRadius = 10
        imgImage.layer.cornerRadius = 10
    }

}
