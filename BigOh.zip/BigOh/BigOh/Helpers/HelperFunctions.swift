//
//  HelperFunctions.swift
//  BigOh
//
//  Created by Palak Satti on 19/10/24.
//


import UIKit

class HelperFunctions {
    
    static func showAlertMessage(on vc: UIViewController,title: String?, message: String?){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        vc.present(alert, animated: true)
    
    }
    
}

extension UIButton {
    func applyGradient(colors: [UIColor], cornerRadius: CGFloat = 0) {
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = colors.map { $0.cgColor }
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.frame = self.bounds
        
        self.layer.cornerRadius = cornerRadius
        self.layer.masksToBounds = true
        self.layer.insertSublayer(gradientLayer, at: 0)
    }
}
