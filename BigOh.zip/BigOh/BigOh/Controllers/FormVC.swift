//
//  FormVC.swift
//  BigOh
//
//  Created by Palak Satti on 19/10/24.
//

import UIKit
import Lottie //animation

class FormVC: UIViewController, UITextFieldDelegate {
    
    //MARK: - IB OUTLETS
    @IBOutlet weak var txtFieldUser: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var lottieAnimation: LottieAnimationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFieldUser.delegate = self
        txtFieldUser.layer.borderWidth = 1
        txtFieldUser.layer.cornerRadius = 10
        txtFieldUser.layer.borderColor = UIColor.systemPurple.cgColor
        btnSubmit.addTarget(self, action: #selector(submitPressed), for: .touchUpInside)
        //APPLYING GRADIENT
        btnSubmit.applyGradient(colors: [.systemPink, .systemPurple], cornerRadius: 10)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
        
    }
    
    @objc func dismissKeyboard() {
        txtFieldUser.resignFirstResponder()
    }
    
    @objc func submitPressed() {
        if txtFieldUser.text?.isEmpty ?? true {
            HelperFunctions.showAlertMessage(on: self, title: "🧐", message: "Please enter your name")
        } else {
            lottieAnimation.animation = LottieAnimation.named("tickmark")
            lottieAnimation.loopMode = .playOnce
            lottieAnimation.contentMode = .scaleAspectFill
            
            lottieAnimation.play { (finished) in
                if finished {
                    print("Lottie animation finished playing")
                    self.lottieAnimation.isHidden = true
                }
            }
            txtFieldUser.text = ""
        }
        
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if let gradientLayer = btnSubmit.layer.sublayers?.first as? CAGradientLayer {
            gradientLayer.frame = btnSubmit.bounds
        }
    }
}
