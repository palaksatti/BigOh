//
//  ImagesVC.swift
//  BigOh
//
//  Created by Palak Satti on 18/10/24.
//

import UIKit
import SVProgressHUD //loader
import SDWebImage //image caching

class ImagesVC: UIViewController, UITabBarDelegate,UIGestureRecognizerDelegate  {
    
    //MARK: - IB OUTLETS
    @IBOutlet weak var tabBar: UITabBar!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var imagesCollectionView: UICollectionView!
    @IBOutlet weak var imagesTabBar: UITabBarItem!
    @IBOutlet weak var formTabbarItem: UITabBarItem!
    
    //MARK: - VARIABLES
    var client_id = "AislUyKHmVK6wuC1b2g0hi0mSNKwKtTncs5hoouuwuk"
    var isLoading: Bool = false
    var currentPage: Int = 1
    var images: [ImageData] = []
    var imagesByKeyword: [Result] = []
    
    
    //MARK: - VIEW LIFECYCLE METHODS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.delegate = self
        tabBar.delegate = self
        imagesCollectionView.dataSource = self
        imagesCollectionView.delegate = self
        imagesCollectionView.register(UINib(nibName: "ImagesCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ImagesCollectionViewCell")
        tabBar.selectedItem = imagesTabBar
        tabBar.tintColor = .text
        tabBar.unselectedItemTintColor = .lightGray
        fetchImagesWhenLoading()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.delegate = self
        view.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tabBar.selectedItem = imagesTabBar
    }
    
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if tabBar.selectedItem == formTabbarItem{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let formVC = storyboard.instantiateViewController(identifier: "FormVC") as? FormVC {
                self.navigationController?.pushViewController(formVC, animated: true)
            }
        }
    }
    
    @objc func dismissKeyboard() {
        searchBar.resignFirstResponder()
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if let tabBar = self.tabBar, tabBar.frame.contains(touch.location(in: view)) {
            return false
        }
        return true
    }
    
}

// MARK: - COLLECTIONVIEW METHODS

extension ImagesVC: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return searchBar.text?.isEmpty == true ? images.count : imagesByKeyword.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImagesCollectionViewCell", for: indexPath) as? ImagesCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        if searchBar.text?.isEmpty == true {
            let imageData = images[indexPath.row]
            cell.imgImage.sd_setImage(with: URL(string: imageData.urls?.regular ?? ""), placeholderImage: UIImage(systemName: "photo.on.rectangle.angled"))
            
        }else{
            let imageData = imagesByKeyword[indexPath.row]
            cell.imgImage.sd_setImage(with: URL(string: imageData.urls?.regular ?? ""), placeholderImage: UIImage(systemName: "photo.on.rectangle.angled"))
            
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 10) / 2
        return CGSize(width: width, height: width)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        if offsetY > contentHeight - scrollView.frame.height {
            if !isLoading {
                currentPage += 1
                fetchImagesWhenLoading()
            }
        }
    }
}

// MARK: - API CALLING

extension ImagesVC {
    
    //general loading
    func fetchImagesWhenLoading() {
        isLoading = true
        SVProgressHUD.show()
        
        let urlString = "https://api.unsplash.com/photos?page=\(currentPage)&client_id=\(client_id)"
        guard let url = URL(string: urlString) else {
            HelperFunctions.showAlertMessage(on: self, title: "No data", message: "There is some issue with the URL.")
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                SVProgressHUD.dismiss()
            }
            
            if let error = error {
                print("Error fetching images: \(error)")
                DispatchQueue.main.async {
                    HelperFunctions.showAlertMessage(on: self, title: "Oops", message: "Failed to load images.")
                }
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async {
                    HelperFunctions.showAlertMessage(on: self, title: "No data", message: "No data found for the given URL.")
                }
                return
            }
            
            do {
                let imageResponse = try JSONDecoder().decode([ImageData].self, from: data)
                self.images.append(contentsOf: imageResponse)
                DispatchQueue.main.async {
                    self.imagesCollectionView.reloadData()
                    self.isLoading = false
                }
            } catch {
                print("Error decoding JSON: \(error)")
                DispatchQueue.main.async {
                    HelperFunctions.showAlertMessage(on: self, title: "No data", message: "No data found for the given URL.")
                    self.isLoading = false
                }
            }
        }.resume()
    }
    
    //based on the keyword
    func getImagesByKeyword() {
        isLoading = true
        SVProgressHUD.show()
        
        let keyword = searchBar.text ?? ""
        
        let urlString = "https://api.unsplash.com/search/photos?page=\(currentPage)&query=\(keyword)&client_id=\(client_id)"
        guard let url = URL(string: urlString) else { return }
        

        DispatchQueue.global(qos: .background).async {
            URLSession.shared.dataTask(with: url) { data, response, error in
                DispatchQueue.main.async {
                    SVProgressHUD.dismiss()
                }
                
                if let error = error {
                    print("Error fetching images: \(error)")
                    DispatchQueue.main.async {
                        HelperFunctions.showAlertMessage(on: self, title: "OH NO!", message: "Looks like there is some problem, please try again later.")
                    }
                    return
                }
                
                guard let data = data else {
                    DispatchQueue.main.async {
                        HelperFunctions.showAlertMessage(on: self, title: "No data", message: error?.localizedDescription)
                    }
                    return
                }
                
                do {
                    let keywordResponse = try JSONDecoder().decode(ImageKeywordResponse.self, from: data)
                    
                    DispatchQueue.main.async {
                        if let results = keywordResponse.results, !results.isEmpty {
                            self.imagesByKeyword.append(contentsOf: results)
                            print("keyword is \(keyword)")
                            print("=====================================")
                            print(keywordResponse)
                            self.imagesCollectionView.reloadData()
                            self.isLoading = false
                        } else {
                            DispatchQueue.main.async {
                                let alert = UIAlertController(title: "Oh No!", message: "Looks like there is no image for \(keyword). Try searching for another keyword.", preferredStyle: .alert)
                                let action = UIAlertAction(title: "OK", style: .default) { _ in
                                    self.searchBar.text = ""
                                    self.currentPage = 1
                                    self.imagesByKeyword.removeAll()
                                    self.fetchImagesWhenLoading()
                                    self.imagesCollectionView.reloadData()
                                }
                                alert.addAction(action)
                                self.present(alert, animated: true)
                                self.isLoading = false
                            }
                        }
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                    DispatchQueue.main.async {
                        HelperFunctions.showAlertMessage(on: self, title: "No data", message: "No data found for the given URL.")
                        self.isLoading = false
                    }
                }
            }.resume()
        }
    }

    
}

extension ImagesVC: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let keyword = searchBar.text, !keyword.isEmpty else {
            HelperFunctions.showAlertMessage(on: self, title: "Oops", message: "Please Enter some text so that I can search for images")
            return
        }
        
        currentPage = 1
        imagesByKeyword.removeAll()
        self.imagesCollectionView.reloadData()
        self.getImagesByKeyword()
        searchBar.resignFirstResponder()
        
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        currentPage = 1
        imagesByKeyword.removeAll()
        self.imagesCollectionView.reloadData()
        fetchImagesWhenLoading()
        searchBar.resignFirstResponder()
    }
    
}
